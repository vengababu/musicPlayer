//
//  MusicSingleton.swift
//  MusicPlayer
//
//  Created by Venga Babu on 27/10/23.
//

import Foundation
import AVFoundation


class MusicSingleton {
    static let sharedInstance = MusicSingleton()
    private init() {}
    
    var player: AVAudioPlayer?
    var vwModel:SongViewModel?
    var playerIndex = -1
    
    func playTheVideo() {
        if playerIndex == -1 {
            return
        }
        if let url = getThePlayBackUrl(title: vwModel?.songList[playerIndex].title ?? "") {
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback)
                try AVAudioSession.sharedInstance().setActive(true)
                
            }catch {
                print("unable to play \(error)")
            }
            
            self.playTheVideo(url: url)
        }
    }
    
    func downloadtheUrl(url: String, title: String) {
        let documentUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationurl = documentUrl.appendingPathComponent("\(title).mp3")
        vwModel?.downLoadTheUrl(url: url, destinationUrl: destinationurl)
        self.playTheVideo()
        vwModel?.isApiSuccess = { [weak self] type in
            DispatchQueue.main.async {
                if !(self?.player?.isPlaying ?? true) {
                    self?.playTheVideo()
                }
            }
        }
    }
    
    func getThePlayBackUrl(title: String) -> URL?{
        let documentUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationurl = documentUrl.appendingPathComponent("\(title).mp3")
        return destinationurl
    }
    
    func playTheVideo(url:URL) {
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            self.player?.play()
        }catch {
            print("unable to play \(error)")
        }
    }
}
