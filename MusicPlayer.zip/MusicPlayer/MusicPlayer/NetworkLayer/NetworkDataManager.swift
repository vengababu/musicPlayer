//
//  NetworkDataManager.swift
//  MusicPlayer
//
//  Created by Venga Babu on 27/10/23.
//

import Foundation

class NetworkDataManager {
    static let sharedInstance = NetworkDataManager()
    private init() {}
    
    func makeTheApiCall(url: String, completion: @escaping(([[String:Any]])->())) {
        let urlSession = URLSession.shared
        let apiUrl = URL(string: url)!
        let task = urlSession.dataTask(with: URLRequest(url: apiUrl)) { data, response, err in
            do {
                let dict = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [[String:Any]]
                completion(dict ?? [])
            }catch {
                completion([])
            }
        }
        task.resume()
    }
    
    func downTheVideo(audioUrl: String, destinationUrl: URL, completion: @escaping(()->())) {
        let urlSession = URLSession.shared
        let apiUrl = URL(string: audioUrl)!
        let downTask = urlSession.downloadTask(with:  URLRequest(url: apiUrl)) { videoUrl, response, err in
            if err == nil {
                do {
                    try FileManager.default.moveItem(at: videoUrl!, to: destinationUrl)
                    completion()
                }catch {
                    print("\(err?.localizedDescription ?? "")")
                }
            }
        }
        downTask.resume()
    }
}
