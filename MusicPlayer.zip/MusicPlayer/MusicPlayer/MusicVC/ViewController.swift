//
//  ViewController.swift
//  MusicPlayer
//
//  Created by Venga Babu on 27/10/23.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var vwModel = SongViewModel()
    var player: AVAudioPlayer?

    @IBOutlet weak var tblVw: UITableView!
    var playerIndex = -1
    override func viewDidLoad() {
        super.viewDidLoad()
        self.makeTheApiCallForSongs()
        // Do any additional setup after loading the view.
    }
    
    func makeTheApiCallForSongs() {
        MusicSingleton.sharedInstance.vwModel = vwModel
        vwModel.getTheSongsList()
        vwModel.isApiSuccess = { [weak self] type in
            if type == .song {
                DispatchQueue.main.async {
                    self?.tblVw.reloadData()
                }
            }
        }
    }

    
    @objc func playTheMusic(_ sender: UIButton) {
        if sender.isSelected {
            player?.pause()
            sender.isSelected = false
            return
        }
        sender.isSelected = !sender.isSelected
        MusicSingleton.sharedInstance.playerIndex = sender.tag
        MusicSingleton.sharedInstance.downloadtheUrl(url: vwModel.songList[sender.tag].url ?? "", title: vwModel.songList[sender.tag].title ?? "")
    }
    
  
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vwModel.songList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongsListTblVwCell", for: indexPath) as? SongsListTblVwCell
        cell?.updateTheContent(content: vwModel.songList[indexPath.row])
        cell?.playBtn.tag = indexPath.row
        cell?.playBtn.addTarget(self, action:#selector(playTheMusic(_:)), for: .touchUpInside)
        cell?.playBtn.isSelected = playerIndex == indexPath.row
        return cell!
    }
}
