//
//  SongViewModel.swift
//  MusicPlayer
//
//  Created by Venga Babu on 27/10/23.
//

import Foundation
enum SongList {
    case song
    case download
}

class SongViewModel {
    var network = NetworkDataManager.sharedInstance
    var songList:[SongModel] = []
    var isApiSuccess:((SongList)->())?
    
    func getTheSongsList() {
        network.makeTheApiCall(url: "https://www.jsonkeeper.com/b/C47J") { [weak self] data in
            self?.songList = data.map({SongModel(dict: $0)})
            self?.isApiSuccess?(.song)
        }
    }
    
    func downLoadTheUrl(url: String,destinationUrl: URL) {
        network.downTheVideo(audioUrl: url, destinationUrl: destinationUrl) { [weak self] in
            self?.isApiSuccess?(.download)
        }
    }
}
