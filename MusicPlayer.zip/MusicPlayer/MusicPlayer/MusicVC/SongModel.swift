//
//  SongModel.swift
//  MusicPlayer
//
//  Created by Venga Babu on 27/10/23.
//

import Foundation

struct SongModel: Codable {
    var title:String?
    var artist: String?
    var album: String?
    var url: String?
    
    enum codingKeys: String, CodingKey {
        case title
        case artist
        case album
        case url
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try? container.decodeIfPresent(String.self, forKey: .title) ?? ""
        self.artist = try? container.decodeIfPresent(String.self, forKey: .artist) ?? ""
        self.album = try? container.decodeIfPresent(String.self, forKey: .album) ?? ""
        self.url = try? container.decodeIfPresent(String.self, forKey: .url) ?? ""
    }
    
    init(dict:[String:Any]) {
        self.title = dict["title"] as? String ?? ""
        self.artist = dict["artist"] as? String ?? ""
        self.album = dict["album"] as? String ?? ""
        self.url = (dict["url"] as? String ?? "").replacingOccurrences(of: " ", with: "")
    }
}
